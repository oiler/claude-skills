"""Enumerate the third-party trust surface.

Each enumerate_* function returns a list[Item] for one surface.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from snapshot import Item

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class SkipEvent:
    surface: str    # "plugin" | "skill" | "hook"
    name: str       # best-effort identifier of what was skipped
    reason: str     # human-readable cause, e.g. "malformed plugin.json: ..."


@dataclass(frozen=True)
class McpSource:
    kind: str           # "npm" | "pip" | "git" | "local"
    package: str        # registry name, git URL, or local path
    version: str | None


_NPM_SPEC = re.compile(r"^(?P<pkg>(?:@[^/]+/)?[^@]+)(?:@(?P<ver>[^@]+))?$")
_PIP_SPEC = re.compile(r"^(?P<pkg>[A-Za-z0-9_.-]+)(?:==(?P<ver>[^=]+))?$")


def parse_mcp_source(command: str, args: list[str]) -> McpSource:
    """Infer source kind/package/version from how an MCP server is launched."""
    # npm: npx [-y] @scope/pkg@version
    if command in {"npx", "bunx"}:
        for arg in args:
            if arg.startswith("-"):
                continue
            m = _NPM_SPEC.match(arg)
            if m:
                return McpSource(kind="npm", package=m["pkg"], version=m["ver"])

    # pip: uvx pkg==version  or  python -m pkg (skip, no version)
    if command in {"uvx", "pipx"}:
        for arg in args:
            if arg.startswith("-"):
                continue
            m = _PIP_SPEC.match(arg)
            if m:
                return McpSource(kind="pip", package=m["pkg"], version=m["ver"])

    # Local path
    if args and args[0].startswith("/"):
        return McpSource(kind="local", package=args[0], version=None)

    return McpSource(kind="local", package=f"{command} {' '.join(args)}".strip(),
                     version=None)


def enumerate_mcp_servers(payload: dict[str, Any]) -> list[Item]:
    items: list[Item] = []
    for entry in payload.get("servers", []):
        src = parse_mcp_source(entry.get("command", ""), entry.get("args", []))
        items.append(Item(
            surface="mcp",
            name=entry["name"],
            source=f"{src.kind}:{src.package}",
            version=src.version,
            publish_date=None,        # filled by signals.py via registry lookup
            publisher=None,
            capabilities=sorted(entry.get("tools", [])),
            source_url=None,
            content_hash=None,
        ))
    return items


def enumerate_plugins(plugins_root: Path, skips: list[SkipEvent] | None = None) -> list[Item]:
    """Walk plugin caches under plugins_root looking for plugin.json files."""
    items: list[Item] = []
    if not plugins_root.exists():
        return items

    for manifest in plugins_root.rglob("plugin.json"):
        try:
            data = json.loads(manifest.read_text())
        except (json.JSONDecodeError, OSError) as e:
            log.warning("skipping plugin at %s: %s", manifest.parent, e)
            if skips is not None:
                skips.append(SkipEvent(
                    surface="plugin",
                    name=manifest.parent.name,
                    reason=f"malformed plugin.json: {e}",
                ))
            continue

        name = data.get("name") or manifest.parent.name
        version = data.get("version")
        repo = data.get("repository")
        source = f"git:{repo}" if repo else f"local:{manifest.parent}"

        capabilities: list[str] = []
        capabilities += [f"skill:{s}" for s in data.get("skills", [])]
        capabilities += [f"command:{c}" for c in data.get("commands", [])]
        for srv in data.get("mcpServers", []):
            srv_name = srv if isinstance(srv, str) else srv.get("name", "?")
            capabilities.append(f"mcpServer:{srv_name}")

        # Hooks ship as a sibling hooks.json
        hooks_file = manifest.parent / "hooks.json"
        if hooks_file.exists():
            try:
                hooks_data = json.loads(hooks_file.read_text())
                capabilities += [f"hook:{event}" for event in hooks_data.keys()]
            except (json.JSONDecodeError, OSError) as e:
                log.warning("skipping hooks.json at %s: %s", hooks_file, e)
                if skips is not None:
                    skips.append(SkipEvent(
                        surface="hook",
                        name=f"{name}:hooks.json",
                        reason=f"malformed hooks.json: {e}",
                    ))

        items.append(Item(
            surface="plugin",
            name=name,
            source=source,
            version=version,
            publish_date=None,
            publisher=None,
            capabilities=sorted(capabilities),
            source_url=repo,
            content_hash=None,
        ))

    return items


import hashlib
from datetime import datetime


def _parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---"):
        return {}
    end = text.find("\n---", 4)
    if end == -1:
        return {}
    out = {}
    for line in text[4:end].splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            out[k.strip()] = v.strip()
    return out


def enumerate_skills(skills_root: Path, skips: list[SkipEvent] | None = None) -> list[Item]:
    items: list[Item] = []
    if not skills_root.exists():
        return items

    for skill_dir in sorted(p for p in skills_root.iterdir() if p.is_dir()):
        md = skill_dir / "SKILL.md"
        if not md.exists():
            continue
        try:
            text = md.read_text()
        except OSError as e:
            log.warning("skipping skill at %s: %s", skill_dir, e)
            if skips is not None:
                skips.append(SkipEvent(
                    surface="skill",
                    name=skill_dir.name,
                    reason=f"malformed SKILL.md: {e}",
                ))
            continue

        fm = _parse_frontmatter(text)
        name = fm.get("name") or skill_dir.name
        mtime = datetime.fromtimestamp(md.stat().st_mtime).isoformat()
        h = hashlib.sha256(text.encode()).hexdigest()

        # Resolve symlink to detect upstream source
        if skill_dir.is_symlink():
            source = f"local:{skill_dir.resolve()}"
        else:
            source = f"local:{skill_dir}"

        items.append(Item(
            surface="skill",
            name=name,
            source=source,
            version=mtime,
            publish_date=None,
            publisher=None,
            capabilities=[],   # skills don't declare tools in frontmatter
            source_url=None,
            content_hash=h,
        ))
    return items


def enumerate_hooks(settings_files: list[tuple[Path, str]], skips: list[SkipEvent] | None = None) -> list[Item]:
    """settings_files: list of (path, scope) where scope is 'user' or 'project'."""
    items: list[Item] = []
    for path, scope in settings_files:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError) as e:
            log.warning("skipping settings at %s: %s", path, e)
            if skips is not None:
                skips.append(SkipEvent(
                    surface="hook",
                    name=f"{scope}:settings.json",
                    reason=f"malformed settings.json: {e}",
                ))
            continue

        for event, registrations in (data.get("hooks") or {}).items():
            for reg in registrations:
                matcher = reg.get("matcher", "")
                for hook in reg.get("hooks", []):
                    command = hook.get("command", "")
                    name = f"{scope}:{event}:{command}"
                    h = hashlib.sha256(command.encode()).hexdigest()
                    items.append(Item(
                        surface="hook",
                        name=name,
                        source=f"settings:{scope}",
                        version=None,
                        publish_date=None,
                        publisher=None,
                        capabilities=sorted([
                            f"event:{event}",
                            f"matcher:{matcher}",
                        ]),
                        source_url=None,
                        content_hash=h,
                    ))
    return items
